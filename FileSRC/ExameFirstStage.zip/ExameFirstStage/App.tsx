import React, {useState} from 'react';

import './App.css';
import s from './App.module.css';

function App() {
  let [number, setNumber] = useState<number>(0)

    const limitNumber = number === 5 ? s.limit : s.noLimit; 

  const plusNumber = () => {
    if (number <= 4){
      let rise = ++number;
      setNumber(rise) 
    }
  }
  const minusNumber = () => {
    if(number > 0 ){
      let decrease = --number;
      setNumber(decrease)
    }
  }
  const resetResult = () => {
    if (number > 0){
      setNumber(0)
    }
  }
  const disabledMin = number === 0 ?  true : false;
  const disabledMax = number === 5 ?  true : false;
  const disabledReset = number === 0 ? true : false;

  return (
    <div className='counter'>
      <button onClick={minusNumber} disabled={disabledMin}>-</button>
      <div className={limitNumber}>{number}</div>
      <button onClick={plusNumber} disabled={disabledMax}>+</button>
      <button className={s.reset} onClick={resetResult} disabled={disabledReset}>reset</button>
    </div>
  )
}



export default App;